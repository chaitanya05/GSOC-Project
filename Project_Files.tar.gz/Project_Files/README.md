This is where I will be updating and commiting my project deliverables or code. Every single element that has done can be accessed here. My updates from day-to-day can be found here: saichaitanyagsoc-blog.blogspot.in

Title: Orthorectifying ElectronMicroscope data in reference to a thin section image

zoom.html:
This is a file where you can zoom an image. This hasn't finished yet. The basic code has been implemented. The fuctions are to be implemented. And also some of the attributes need to be defined accordingly.

Work done so far(week-2 from May 26-May 30): This week the work was mainly focused on zooming the image. This is being with use of jQuery and JavaScript. Actually, the previous project(which was done in 2011) was based upon the layers.
