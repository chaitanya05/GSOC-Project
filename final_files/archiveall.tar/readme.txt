Download the OpenLayers compressed file from http://web.iiit.ac.in/~ponnathotasaichaitanya.reddy/project/
Extract the OpenLayers-2.13.1.tar.gz in your desired host address.
Download the files that you have submitted.
Then uncompress in the same fored as done for the OpenLayers file.
The you can access the web page from typing the url(the path in which you saved your files).
